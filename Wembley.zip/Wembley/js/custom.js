jQuery(document).ready(function() {


    jQuery('#topmenu').mobileMenu({
			prependTo:'.mobilenavi'
			});	
	
    jQuery('.pushy').jScrollPane();
    
    
    
});


